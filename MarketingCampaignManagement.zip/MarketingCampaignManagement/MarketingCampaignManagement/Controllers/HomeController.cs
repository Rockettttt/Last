﻿using MarketingCampaignManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MarketingCampaignManagement.Controllers
{
    public class HomeController : Controller
    {
        Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(Users174790 objUser)
        {


            var obj = db.Users174790.Where(a => a.LoginId.Equals(objUser.LoginId) && a.Password.Equals(objUser.Password)).FirstOrDefault();

            if (obj != null/*db.Users174790.Any(a => a.Id.Equals(objUser.Id)&&a.LoginId.Equals(objUser.LoginId) && a.Password.Equals(objUser.Password)&& a.IsAdmin==true)*/)
            {
                if (obj.IsAdmin == true)
                {
                    Session["Id"] = obj.Id.ToString();
                    Session["FullName"] = obj.FullName.ToString();
                    return RedirectToAction("Index", "Admin");
                }
                if (obj.IsAdmin == false)
                {
                    Session["Id"] = obj.Id.ToString();
                    Session["FullName"] = obj.FullName.ToString();
                    return RedirectToAction("Index", "Executer");
                }
            }
            //if (db.Users174790.Any(a => a.Id.Equals(objUser.Id) && a.LoginId.Equals(objUser.LoginId) && a.Password.Equals(objUser.Password) && a.IsAdmin.Equals(false)))
            // {
            //     return RedirectToAction("Index", "Execute");
            // }
            return View();


        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}