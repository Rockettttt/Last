﻿using MarketingCampaignManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MarketingCampaignManagement.Controllers
{
    public class SalesOrderController : Controller
    {
        Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();
        Sales_Order174790 sales = new Sales_Order174790();
        // GET: SalesOrder
        public ActionResult Index()
        {
            return View(db.Sales_Order174790.ToList());
        }
        [HttpPost]
        public ActionResult Index(string id)
        {

            var query = from sale in db.Sales_Order174790.ToList()
                        where sales.LeadId== Convert.ToInt32(id)
                        select sale;

            return View(query);
        }


       

        // GET: SalesOrder/Create
        public ActionResult Create()
        {
            ViewBag.LeadId = new SelectList(db.Leads174790, "Id", "ConsumerName");
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Order_Id,LeadId,ShippingAddress,BillingAddress,CreatedOn,PaymentMode")] Sales_Order174790 sales_Order174790)
        {
            if (ModelState.IsValid)
            {
                db.Sales_Order174790.Add(sales_Order174790);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.LeadId = new SelectList(db.Leads174790, "Id", "ConsumerName", sales_Order174790.LeadId);
            return View(sales_Order174790);
        }

        // POST: SalesOrder/Create
        //[HttpPost]
        //public ActionResult Create(int orderid,int Leadid,string ShippingAddress,string BillingAddress,string PaymentMode)
        //{



        //    sales.Order_Id = sales.Order_Id;

        //    sales.LeadId = Leadid;

        //    sales.ShippingAddress = ShippingAddress;
        //    sales.BillingAddress = BillingAddress;

        //    sales.PaymentMode = PaymentMode;


        //    //Adds an entity in a pending insert state to this System .Data.Linq.Table<TEntity> and parameter is the entity which
        //    db.Sales_Order174790.Add(sales);
        //    //Executes the appropriate commands to implement the changes to the database
        //    db.SaveChanges();
        //    ViewBag.Message = "Data Inserted";
        //    return RedirectToAction("Index");
        //}
        // GET: SalesOrder/Edit/5
        public ActionResult Edit(int? id)
        {
            sales = db.Sales_Order174790.Find(id);
            return View(sales);
        }

        // POST: SalesOrder/Edit/5
        [HttpPost]
        public ActionResult Edit(Sales_Order174790 ld)
        {
            var pd = db.Sales_Order174790.Where(x => x.Order_Id == ld.Order_Id).FirstOrDefault();
            
            sales.LeadId = pd.LeadId;
            sales.ShippingAddress = pd.ShippingAddress;
            sales.BillingAddress = pd.BillingAddress;
            sales.CreatedOn = pd.CreatedOn;
            sales.PaymentMode = pd.PaymentMode;

            if (TryUpdateModel(pd))
            {
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();

        }

        // GET: SalesOrder/Delete/5
        public ActionResult Delete(int? id)
        {
            sales = db.Sales_Order174790.Find(id);
            return View(sales);
        }

        // POST: SalesOrder/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {
            var pd = db.Sales_Order174790.Where(x => x.Order_Id == id).FirstOrDefault();
            db.Sales_Order174790.Remove(pd);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
