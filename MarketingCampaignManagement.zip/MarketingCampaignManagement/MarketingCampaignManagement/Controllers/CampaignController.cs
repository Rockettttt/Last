﻿using MarketingCampaignManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace MarketingCampaignManagement.Controllers
{
    public class CampaignController : Controller
    {
        Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();
        Campaign174790 camp = new Campaign174790();
        // GET: Campaign
        public ActionResult Index()
        {
            return View(db.Campaign174790.ToList());
        }
        [HttpPost]
        public ActionResult Index(string ID)
        {
            var query = from Campg  in db.Campaign174790.ToList()
                        where camp.Id == Convert.ToInt32(ID)
                        select Campg;

            return View(query);
        }

        
        // GET: Campaign/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Campaign/Create
        [HttpPost]
        public ActionResult Create(string name,string venue,int assignedTo,DateTime startedOn, DateTime CompletedOn, bool IsOpen)
        {
            camp.Name = name;
            camp.Venue = venue;
            camp.AssignedTo = assignedTo;
            camp.StartedOn = startedOn;
            camp.CompletedOn = CompletedOn;
            camp.IsOpen = IsOpen;
            
            //Adds an entity in a pending insert state to this System .Data.Linq.Table<TEntity> and parameter is the entity which
            db.Campaign174790.Add(camp);
            //Executes the appropriate commands to implement the changes to the database
            db.SaveChanges();
            ViewBag.Message = "Data Inserted";
            return RedirectToAction("Index");
        }

        ////GET: Campaign/Edit/5
        //public ActionResult Edit(int? id)
        //{

        //    camp = db.Campaign174790.Find(id);
        //    return View(camp);
        //}

        //// POST: Campaign/Edit/5
        //[HttpPost]
        //public ActionResult Edit(Campaign174790 cap)
        //{
        //    var caps = db.Campaign174790.Where(x => x.Id == cap.Id).FirstOrDefault();
        //    camp.Name = cap.Name;
        //    camp.Venue =cap.Venue;
        //    camp.AssignedTo = cap.AssignedTo;
        //    camp.StartedOn = cap.StartedOn;
        //    camp.CompletedOn = cap.CompletedOn;
        //    camp.IsOpen = cap.IsOpen;

        //    if (TryUpdateModel(caps))
        //    {
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View();
        //}
        // GET: Campaign174790/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Campaign174790 campaign174790 = db.Campaign174790.Find(id);
            if (campaign174790 == null)
            {
                return HttpNotFound();
            }
            ViewBag.AssignedTo = new SelectList(db.Users174790, "Id", "FullName", campaign174790.AssignedTo);
            return View(campaign174790);
        }

        // POST: Campaign174790/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Venue,AssignedTo,StartedOn,CompletedOn,IsOpen")] Campaign174790 campaign174790)
        {
            if (ModelState.IsValid)
            {
                db.Entry(campaign174790).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.AssignedTo = new SelectList(db.Users174790, "Id", "FullName", campaign174790.AssignedTo);
            return View(campaign174790);
        }

        // GET: Campaign/Delete/5
        public ActionResult Delete(int? id)
        {
            camp = db.Campaign174790.Find(id);
            return View(camp);
        }

        // POST: Campaign/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {

            var cap = db.Campaign174790.Where(x => x.Id== id).FirstOrDefault();
            db.Campaign174790.Remove(cap);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Search(string assignedto)
        {
            var results = (from cap in db.Campaign174790 where cap.AssignedTo.ToString() == assignedto select cap);
            return View(results);
        }
        /// <summary>
        /// : This functionality will allow the administrator to see all the campaigns assigned to each executive and total number of leads generated during the campaign.
        /// </summary>
        /// <param name="Executiveid"></param>
        /// <returns></returns>
        /// 
       
        public ActionResult Search1(string name)
        {

            var results = (from cap in db.Campaign174790 where cap.Name == name select cap);

            return View(results);           
          }
        public ActionResult Search3(string id )
        {
            var results = (from cap in db.Campaign174790 where cap.Id.ToString() == id select cap);

            return View(results);
        }
        public ActionResult Search3(Campaign174790 cap)
        {
            return RedirectToAction("Search4");
        }
       


        public ActionResult Search4(int? id)
        {
            camp = db.Campaign174790.Find(id);
            return View(camp);
        }
        [HttpPost]
        public ActionResult Search4(Campaign174790 cap)
        {
            var caps = db.Campaign174790.Where(x => x.Id == cap.Id).FirstOrDefault();

           
            camp.AssignedTo = cap.AssignedTo;

            if (TryUpdateModel(caps))
            {
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();

        }

        
        public ActionResult Search5(string Assignedto)
        {
            var caps = (from Campaign in db.Campaign174790 where Campaign.AssignedTo.ToString()==Assignedto select Campaign);


            return View(caps.ToList());
        }

    }
}
