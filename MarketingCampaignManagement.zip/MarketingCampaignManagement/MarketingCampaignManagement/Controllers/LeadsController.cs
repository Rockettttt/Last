﻿using MarketingCampaignManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace MarketingCampaignManagement.Controllers
{
    public class LeadsController : Controller
    {

        Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();
        Leads174790 lea = new Leads174790();
        // GET: Leads
        public ActionResult Index()
        {
            return View(db.Leads174790.ToList());
        }
        [HttpPost]
        public ActionResult Index(string id)
        {

            var query = from lead in db.Leads174790.ToList()
                        where lea.Id == Convert.ToInt32(id)
                        select lead;

            return View(query);
        }

        //// GET: Leads/Details/5
        //public ActionResult Details(int id)
        //{
        //    return View();
        //}
        // GET: Leads174790/Create
        public ActionResult Create()
        {
            ViewBag.CampaignId = new SelectList(db.Campaign174790, "Id", "Name");
            ViewBag.ProductId = new SelectList(db.Products174790, "ProductId", "Name");
            return View();
        }

        // POST: Leads174790/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,CampaignId,ConsumerName,EmailAddress,PhoneNo,PreferredModeOfCommunication,DateAppoached,Name,Status")] Leads174790 leads174790)
        {
            if (ModelState.IsValid)
            {
                db.Leads174790.Add(leads174790);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CampaignId = new SelectList(db.Campaign174790, "Id", "Name", leads174790.CampaignId);
            ViewBag.ProductId = new SelectList(db.Products174790, "ProductId", "Name", leads174790.ProductId);
            return View(leads174790);
        }

        //// GET: Leads/Create
        //public ActionResult Create()
        //{
        //    return View();
        //}

        //// POST: Leads/Create
        //[HttpPost]
        //public ActionResult Create(int id,int campaginid,string ConsumerName,string EmailAddress,string PhoneNo,string PreferredModeOfCommunication,DateTime DateAppoached,string Status)
        //{
        //    lea.Id = id;
        //    lea.CampaignId = campaginid;
        //    lea.ConsumerName = ConsumerName;
        //    lea.EmailAddress = EmailAddress;
        //    lea.PhoneNo = PhoneNo;
        //    lea.PreferredModeOfCommunication = PreferredModeOfCommunication;
        //    lea.DateAppoached = DateAppoached;

        //    lea.Status = Status;

        //    //Adds an entity in a pending insert state to this System .Data.Linq.Table<TEntity> and parameter is the entity which
        //    db.Leads174790.Add(lea);
        //    //Executes the appropriate commands to implement the changes to the database
        //    db.SaveChanges();
        //    ViewBag.Message = "Data Inserted";
        //    return RedirectToAction("Index");
        //}

        // GET: Leads/Edit/5
        public ActionResult Edit(int? id)
        {

            lea = db.Leads174790.Find(id);
            return View(lea);
        }

        // POST: Leads/Edit/5
        [HttpPost]
        public ActionResult Edit(Leads174790 ld)
        {
            var pd = db.Leads174790.Where(x => x.Id == ld.Id).FirstOrDefault();
            lea.CampaignId = pd.CampaignId;
            lea.ConsumerName = pd.ConsumerName;
            lea.EmailAddress = pd.EmailAddress;
            lea.PhoneNo = pd.PhoneNo;
            lea.PreferredModeOfCommunication = pd.PreferredModeOfCommunication;
            lea.DateAppoached = pd.DateAppoached;
            lea.ProductId = pd.ProductId;
            lea.Status = pd.Status;


            if (TryUpdateModel(pd))
            {
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();

        }

        // GET: Leads/Delete/5
        public ActionResult Delete(int? id)
        {
            lea = db.Leads174790.Find(id);
            return View(lea);
        }

        // POST: Leads/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {

            var pd = db.Leads174790.Where(x => x.Id == id).FirstOrDefault();
            db.Leads174790.Remove(pd);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Using this option administrator will be able to see all the leads that are gathered during a particular marketing campaign.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult Search2(string name)
        {
            var caps = (from Lead in db.Leads174790 where Lead.ConsumerName.ToString() == name select Lead);


            return View(caps.ToList());
        }
        public ActionResult Search(string  name)
        {
            //  name = db.Leads174790 where Leads174790.ConsumerName== name.ConsumerName;
           ViewBag.name = new SelectList(db.Leads174790, "CampaignId", "ConsumerName", name);
            if (!String.IsNullOrWhiteSpace(name))
            {
                return View();
              }
            else
            {
                return View(db.Leads174790.Where(x => x.ConsumerName.Contains(name)).FirstOrDefault());
            }
           

       //     return View(caps.ToList());
        }
        /// <summary>
        /// and total number of leads generated during the campaign.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        //public ActionResult Search2(string id)
        //{
        //    var caps = (from Lead in db.Leads174790 where Lead.CampaignId.ToString() == id select Lead);

        //    ViewBag.TotalStudents = caps.Count();
        //    return View();
        //}

        //public ActionResult LeadFollowUp(string campid)
        //{
        //    var caps = (from Lead in db.Leads174790 where Lead.CampaignId.ToString() == campid select Lead);


        //    return View(caps);
        //}



        //// GET: Leads174790/Details/5
        //public ActionResult Searchconsumer(Leads174790 ld)
        //{
        //    var pd = db.Leads174790.Where(x => x.Campaign174790.Name == ).FirstOrDefault();
        //    lea.ConsumerName = pd.ConsumerName;

        //    if (TryUpdateModel(pd))
        //    {
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View();
        //}

        public ActionResult SearchConsumerName()
        {
            ViewBag.CampaignId = new SelectList(db.Campaign174790, "Id", "Name");
            ViewBag.ProductId = new SelectList(db.Products174790, "ProductId", "Name");
            return View();
        }

        // POST: Leads174790/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SearchConsumerName([Bind(Include = "CampaignId")] Leads174790 leads174790)
        {
            if (ModelState.IsValid)
            {

                var query = from lead in db.Leads174790.ToList()
                            where lea.CampaignId == leads174790.CampaignId
                            select lead;


                return View(query);
            }

            ViewBag.CampaignId = new SelectList(db.Campaign174790, "Id", "Name", leads174790.CampaignId);
           
            return View(leads174790);
        }
    }
}
