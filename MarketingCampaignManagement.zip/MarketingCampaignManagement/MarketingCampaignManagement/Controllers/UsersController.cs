﻿using MarketingCampaignManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MarketingCampaignManagement.Controllers
{
    public class UsersController : Controller
    {
        Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();
        Users174790 user= new Users174790();
        // GET: Users
       
        public ActionResult Index()
        {
            var v = db.Users174790.Where(x => x.IsAdmin == false).ToList();
            //return View(db.Users174790.ToList());
            return View(v);

          
        }


        public ActionResult Userss(bool Name)
        {
            Name = false;
            var query = from cud in db.Users174790.ToList()
                        where cud.IsAdmin == Name
                        select cud;

            return View(query);
        }


        // GET: Users/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Users/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        [HttpPost]
        public ActionResult Create(string fullName, string Loginid, string Password,DateTime DateOfJoining, string Address,bool discontinued, bool isadmin)
        {

           
            user.FullName = fullName;
            user.LoginId = Loginid;
            user.Password = Password;
            user.DateOfJoining = DateOfJoining;
            user.Address = Address;
            user.Discontinued = discontinued;
            user.IsAdmin = isadmin;
            //Adds an entity in a pending insert state to this System .Data.Linq.Table<TEntity> and parameter is the entity which
            db.Users174790.Add(user);
            //Executes the appropriate commands to implement the changes to the database
            db.SaveChanges();
            ViewBag.Message = "Data Inserted";
            return RedirectToAction("Index");
        }
        // GET: Users/Edit/5
        public ActionResult Edit(int id)
        {
            user= db.Users174790.Find(id);
            return View(user);
        }

        // POST: Users/Edit/5
        [HttpPost]
        public ActionResult Edit(Users174790 usd )
        {

            var userss = db.Users174790.Where(x => x.Id == usd.Id).FirstOrDefault();
            user.FullName = usd.FullName;
            user.LoginId = usd.LoginId;
            user.Password = usd.Password;
            user.DateOfJoining = usd.DateOfJoining;
            user.Address = usd.Address;
            user.Discontinued = usd.Discontinued;
            user.IsAdmin = usd.IsAdmin;
            if (TryUpdateModel(userss))
            {
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }

        // GET: Users/Delete/5
        public ActionResult Delete(int? id)
        {
            user = db.Users174790.Find(id);
            return View(user);
        }

        // POST: Users/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {
            var cap = db.Users174790.Where(x => x.Id == id).FirstOrDefault();
            db.Users174790.Remove(cap);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
