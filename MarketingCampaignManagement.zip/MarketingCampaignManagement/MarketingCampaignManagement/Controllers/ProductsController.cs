﻿using MarketingCampaignManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MarketingCampaignManagement.Controllers
{
    

    public class ProductsController : Controller
    {
        Training_20Feb_MumbaiEntities db = new Training_20Feb_MumbaiEntities();
        Products174790 prod = new Products174790();
        // GET: Products
        public ActionResult Index()
        {
            return View(db.Products174790.ToList());
        }
        [HttpPost]
        public ActionResult Index(string id)
        {
            var query = from Products in db.Products174790.ToList()
                        where prod.ProductId == Convert.ToInt32(id)
                        select Products;

            return View(query);
        }

        //// GET: Products/Details/5
        //public ActionResult Details(int id)
        //{
        //    return View();
        //}

        // GET: Products/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Products/Create
        [HttpPost]
        public ActionResult Create(string name,string description,double unitprice)
        {
            try
            {
                // TODO: Add insert logic here
                
                prod.Name= name;
                prod.Description = description;
                prod.Unitprice = Convert.ToDecimal(unitprice);
              
                //Adds an entity in a pending insert state to this System .Data.Linq.Table<TEntity> and parameter is the entity which
                db.Products174790.Add(prod);
                //Executes the appropriate commands to implement the changes to the database
                db.SaveChanges();
                ViewBag.Message = "Data Inserted";
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Products/Edit/5
        public ActionResult Edit(int? id)
        {
            prod = db.Products174790.Find(id);
            return View(prod);
        }

        // POST: Products/Edit/5
        [HttpPost]
        public ActionResult Edit(Products174790 prod)
        {
            var pd = db.Products174790.Where(x => x.ProductId == prod.ProductId).FirstOrDefault();
            prod.Name = pd.Name;
            prod.Description = pd.Description;
            prod.Unitprice = pd.Unitprice;
            
            if (TryUpdateModel(pd))
            {
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }

        // GET: Products/Delete/5
        public ActionResult Delete(int? id)
        {

            prod = db.Products174790.Find(id);
            return View(prod);
        }

        // POST: Products/Delete/5
        [HttpPost]
        public ActionResult Delete(int id)
        {

            var pd = db.Products174790.Where(x => x.ProductId == id).FirstOrDefault();
            db.Products174790.Remove(pd);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
