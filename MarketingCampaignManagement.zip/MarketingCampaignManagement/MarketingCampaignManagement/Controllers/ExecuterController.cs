﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MarketingCampaignManagement.Controllers
{
    public class ExecuterController : Controller
    {
        // GET: Executer
        public ActionResult Index()
        {
            return View();
        }
    }
}